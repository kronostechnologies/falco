/*

Copyright (c) 2013-2018 Draios Inc. dba Sysdig.

This file is dual licensed under either the MIT or GPL 2. See MIT.txt
or GPL2.txt for full copies of the license.

*/
#pragma once

#define PROBE_VERSION "85c88952b018fdbce2464222c3303229f5bfcfad"

#define PROBE_NAME "falco"

#define PROBE_DEVICE_NAME "falco"
